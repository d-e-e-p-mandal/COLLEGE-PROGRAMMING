// input two number and add

#include<stdio.h>
//#include<conio.h>
int main ()//int main(void)
{
    int a ,b,sum;
    //clrscr();
    printf("Enter two number : \n");
    scanf("%d %d",&a,&b);
    sum=a+b;
    printf("%d + %d = %d\n",a,b,sum);
    
   // getch();
    return 0;
}
